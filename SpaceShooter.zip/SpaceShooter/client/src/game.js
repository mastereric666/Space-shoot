class SpaceShooterGame {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.scoreElement = document.getElementById('score');
        this.livesElement = document.getElementById('lives');
        this.waveElement = document.getElementById('wave');
        this.gameOverElement = document.getElementById('gameOver');
        this.finalScoreElement = document.getElementById('finalScore');
        this.displayHighScoreElement = document.getElementById('displayHighScore');
        this.menuHighScoreElement = document.getElementById('menuHighScore');
        this.instructionsElement = document.getElementById('instructions');
        this.startBtn = document.getElementById('startBtn');
        this.restartBtn = document.getElementById('restartBtn');
        
        // Game state
        this.gameState = 'menu'; // 'menu', 'playing', 'gameOver'
        this.score = 0;
        this.lives = 3;
        this.maxLives = 3;
        this.gameSpeed = 1;
        this.wave = 1;
        this.enemiesKilled = 0;
        this.enemiesPerWave = 10;
        this.highScore = this.loadHighScore();
        
        // Audio system
        this.sounds = {
            shoot: new Audio('/sounds/success.mp3'),
            hit: new Audio('/sounds/hit.mp3'),
            background: new Audio('/sounds/background.mp3')
        };
        
        // Configure audio
        this.sounds.shoot.volume = 0.3;
        this.sounds.hit.volume = 0.5;
        this.sounds.background.volume = 0.2;
        this.sounds.background.loop = true;
        
        // Player properties
        this.player = {
            x: this.canvas.width / 2,
            y: this.canvas.height - 60,
            width: 30,
            height: 30,
            speed: 5,
            color: '#00ff00'
        };
        
        // Game objects
        this.bullets = [];
        this.enemies = [];
        this.particles = [];
        this.powerUps = [];
        
        // Timing
        this.lastEnemySpawn = 0;
        this.enemySpawnRate = 2000; // milliseconds
        this.lastPowerUpSpawn = 0;
        this.powerUpSpawnRate = 8000; // milliseconds
        this.lastShot = 0;
        this.shotCooldown = 150; // milliseconds
        this.lastTime = 0;
        
        // Power-up effects
        this.rapidFire = false;
        this.rapidFireTime = 0;
        this.multiShot = false;
        this.multiShotTime = 0;
        
        // Input handling
        this.keys = {};
        
        // Initialize
        this.setupEventListeners();
        this.showMenu();
        
        console.log('Space Shooter Game initialized');
    }
    
    setupEventListeners() {
        // Keyboard events
        document.addEventListener('keydown', (e) => {
            this.keys[e.code] = true;
            
            // Prevent spacebar from scrolling page
            if (e.code === 'Space') {
                e.preventDefault();
            }
            
            console.log('Key pressed:', e.code);
        });
        
        document.addEventListener('keyup', (e) => {
            this.keys[e.code] = false;
        });
        
        // Button events
        this.startBtn.addEventListener('click', () => {
            this.startGame();
        });
        
        this.restartBtn.addEventListener('click', () => {
            this.restartGame();
        });
        
        // Prevent context menu on canvas
        this.canvas.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });
    }
    
    showMenu() {
        this.gameState = 'menu';
        this.instructionsElement.classList.remove('hidden');
        this.gameOverElement.classList.add('hidden');
        
        // Update high score display on menu
        this.menuHighScoreElement.textContent = this.highScore;
        
        this.drawBackground();
        this.drawPlayer();
    }
    
    startGame() {
        console.log('Starting game...');
        this.gameState = 'playing';
        this.score = 0;
        this.lives = this.maxLives;
        this.gameSpeed = 1;
        this.wave = 1;
        this.enemiesKilled = 0;
        this.bullets = [];
        this.enemies = [];
        this.particles = [];
        this.powerUps = [];
        this.lastEnemySpawn = performance.now();
        this.lastPowerUpSpawn = performance.now();
        
        // Reset difficulty settings
        this.enemySpawnRate = 2000;
        
        // Reset power-ups
        this.rapidFire = false;
        this.rapidFireTime = 0;
        this.multiShot = false;
        this.multiShotTime = 0;
        
        // Reset player position
        this.player.x = this.canvas.width / 2;
        this.player.y = this.canvas.height - 60;
        
        // Hide menu elements
        this.instructionsElement.classList.add('hidden');
        this.gameOverElement.classList.add('hidden');
        
        // Start background music
        this.sounds.background.currentTime = 0;
        this.sounds.background.play().catch(e => console.log('Audio play failed:', e));
        
        // Update score, lives, and wave display
        this.updateScore();
        this.updateLives();
        this.updateWave();
        
        // Start game loop
        this.gameLoop();
    }
    
    restartGame() {
        console.log('Restarting game...');
        this.startGame();
    }
    
    gameLoop(currentTime = 0) {
        if (this.gameState !== 'playing') return;
        
        const deltaTime = currentTime - this.lastTime;
        this.lastTime = currentTime;
        
        // Update game objects
        this.update(currentTime);
        
        // Render everything
        this.render();
        
        // Continue game loop
        requestAnimationFrame((time) => this.gameLoop(time));
    }
    
    update(currentTime) {
        // Handle input
        this.handleInput();
        
        // Spawn enemies
        if (currentTime - this.lastEnemySpawn > this.enemySpawnRate) {
            this.spawnEnemy();
            this.lastEnemySpawn = currentTime;
            
            // Gradually increase difficulty
            if (this.enemySpawnRate > 500) {
                this.enemySpawnRate -= 10;
            }
            this.gameSpeed += 0.01;
        }
        
        // Spawn power-ups
        if (currentTime - this.lastPowerUpSpawn > this.powerUpSpawnRate) {
            this.spawnPowerUp();
            this.lastPowerUpSpawn = currentTime;
        }
        
        // Update power-up timers
        this.updatePowerUps(currentTime);
        
        // Update bullets
        this.updateBullets();
        
        // Update enemies
        this.updateEnemies();
        
        // Update particles
        this.updateParticles();
        
        // Update power-up objects
        this.updatePowerUpObjects();
        
        // Check collisions
        this.checkCollisions();
        this.checkPowerUpCollisions();
    }
    
    handleInput() {
        // Move left
        if ((this.keys['ArrowLeft'] || this.keys['KeyA']) && this.player.x > 0) {
            this.player.x -= this.player.speed;
        }
        
        // Move right
        if ((this.keys['ArrowRight'] || this.keys['KeyD']) && this.player.x < this.canvas.width - this.player.width) {
            this.player.x += this.player.speed;
        }
        
        // Shoot
        if (this.keys['Space']) {
            const currentTime = performance.now();
            const cooldownTime = this.rapidFire ? 80 : this.shotCooldown;
            
            if (currentTime - this.lastShot > cooldownTime) {
                this.shoot();
                this.lastShot = currentTime;
            }
            
            // Reset key for non-rapid fire mode
            if (!this.rapidFire) {
                this.keys['Space'] = false;
            }
        }
    }
    
    shoot() {
        if (this.multiShot) {
            // Multi-shot: fire 3 bullets
            const angles = [-0.3, 0, 0.3]; // Left, center, right
            
            angles.forEach(angle => {
                const bullet = {
                    x: this.player.x + this.player.width / 2 - 2,
                    y: this.player.y,
                    width: 4,
                    height: 10,
                    speed: 8,
                    vx: Math.sin(angle) * 3, // Horizontal velocity for spread
                    vy: -8, // Vertical velocity
                    color: '#ffff00'
                };
                this.bullets.push(bullet);
            });
        } else {
            // Normal shot
            const bullet = {
                x: this.player.x + this.player.width / 2 - 2,
                y: this.player.y,
                width: 4,
                height: 10,
                speed: 8,
                color: '#ffff00'
            };
            this.bullets.push(bullet);
        }
        
        // Play shoot sound
        this.sounds.shoot.currentTime = 0;
        this.sounds.shoot.play().catch(e => console.log('Shoot sound failed:', e));
        
        console.log('Bullet fired');
    }
    
    spawnEnemy() {
        const enemyTypes = [
            // Basic enemy
            {
                width: 30,
                height: 30,
                speed: 2,
                color: '#ff0000',
                points: 1,
                type: 'basic'
            },
            // Fast enemy
            {
                width: 20,
                height: 20,
                speed: 4,
                color: '#ff6600',
                points: 2,
                type: 'fast'
            },
            // Tank enemy
            {
                width: 40,
                height: 40,
                speed: 1,
                color: '#800000',
                points: 3,
                type: 'tank'
            },
            // Zigzag enemy
            {
                width: 25,
                height: 25,
                speed: 2.5,
                color: '#ff00ff',
                points: 2,
                type: 'zigzag'
            }
        ];
        
        // Choose random enemy type
        const enemyType = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
        
        const enemy = {
            x: Math.random() * (this.canvas.width - enemyType.width),
            y: -enemyType.height,
            width: enemyType.width,
            height: enemyType.height,
            speed: enemyType.speed * this.gameSpeed,
            color: enemyType.color,
            points: enemyType.points,
            type: enemyType.type,
            // For zigzag movement
            direction: Math.random() > 0.5 ? 1 : -1,
            zigzagCounter: 0
        };
        
        this.enemies.push(enemy);
        console.log('Enemy spawned:', enemy.type, 'at position:', enemy.x, enemy.y);
    }
    
    updateBullets() {
        for (let i = this.bullets.length - 1; i >= 0; i--) {
            const bullet = this.bullets[i];
            
            // Update position based on velocity or speed
            if (bullet.vx !== undefined && bullet.vy !== undefined) {
                // Multi-shot bullets with velocity
                bullet.x += bullet.vx;
                bullet.y += bullet.vy;
            } else {
                // Normal bullets
                bullet.y -= bullet.speed;
            }
            
            // Remove bullets that are off screen
            if (bullet.y + bullet.height < 0 || 
                bullet.x + bullet.width < 0 || 
                bullet.x > this.canvas.width) {
                this.bullets.splice(i, 1);
            }
        }
    }
    
    updateEnemies() {
        for (let i = this.enemies.length - 1; i >= 0; i--) {
            const enemy = this.enemies[i];
            
            // Update position based on enemy type
            switch (enemy.type) {
                case 'basic':
                case 'fast':
                case 'tank':
                    enemy.y += enemy.speed;
                    break;
                    
                case 'zigzag':
                    enemy.y += enemy.speed;
                    enemy.zigzagCounter++;
                    // Change direction every 30 frames
                    if (enemy.zigzagCounter % 30 === 0) {
                        enemy.direction *= -1;
                    }
                    enemy.x += enemy.direction * 2;
                    
                    // Keep zigzag enemies on screen
                    if (enemy.x < 0 || enemy.x + enemy.width > this.canvas.width) {
                        enemy.direction *= -1;
                        enemy.x = Math.max(0, Math.min(this.canvas.width - enemy.width, enemy.x));
                    }
                    break;
            }
            
            // Check if enemy reached bottom (lose a life)
            if (enemy.y > this.canvas.height) {
                console.log('Enemy reached bottom - Life lost!');
                this.enemies.splice(i, 1);
                this.loseLife();
                // Don't return, continue processing other enemies
            }
        }
    }
    
    checkCollisions() {
        // Check bullet-enemy collisions
        for (let i = this.bullets.length - 1; i >= 0; i--) {
            const bullet = this.bullets[i];
            
            for (let j = this.enemies.length - 1; j >= 0; j--) {
                const enemy = this.enemies[j];
                
                if (this.isColliding(bullet, enemy)) {
                    // Create explosion particles
                    this.createExplosion(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, enemy.color);
                    
                    // Remove bullet and enemy
                    this.bullets.splice(i, 1);
                    this.enemies.splice(j, 1);
                    
                    // Play hit sound
                    this.sounds.hit.currentTime = 0;
                    this.sounds.hit.play().catch(e => console.log('Hit sound failed:', e));
                    
                    // Increase score based on enemy type
                    this.score += enemy.points;
                    this.enemiesKilled++;
                    this.updateScore();
                    
                    // Check for wave progression
                    this.checkWaveProgression();
                    
                    console.log('Enemy hit! Score:', this.score, 'Enemies killed:', this.enemiesKilled);
                    break;
                }
            }
        }
    }
    
    checkPowerUpCollisions() {
        // Check player-powerup collisions
        for (let i = this.powerUps.length - 1; i >= 0; i--) {
            const powerUp = this.powerUps[i];
            
            if (this.isColliding(this.player, powerUp)) {
                // Remove power-up
                this.powerUps.splice(i, 1);
                
                // Apply power-up effect
                this.activatePowerUp(powerUp.type);
                console.log('Power-up collected:', powerUp.type);
            }
        }
    }
    
    checkWaveProgression() {
        if (this.enemiesKilled >= this.enemiesPerWave * this.wave) {
            this.wave++;
            console.log('Wave', this.wave, 'started!');
            
            // Increase difficulty
            this.gameSpeed += 0.3;
            this.enemySpawnRate = Math.max(500, this.enemySpawnRate - 200);
            
            // Bonus points for completing wave
            this.score += this.wave * 5;
            this.updateScore();
            this.updateWave();
        }
    }
    
    activatePowerUp(type) {
        const duration = 10000; // 10 seconds
        const currentTime = performance.now();
        
        switch (type) {
            case 'rapidfire':
                this.rapidFire = true;
                this.rapidFireTime = currentTime + duration;
                console.log('Rapid fire activated!');
                break;
                
            case 'multishot':
                this.multiShot = true;
                this.multiShotTime = currentTime + duration;
                console.log('Multi-shot activated!');
                break;
        }
    }
    
    isColliding(rect1, rect2) {
        return rect1.x < rect2.x + rect2.width &&
               rect1.x + rect1.width > rect2.x &&
               rect1.y < rect2.y + rect2.height &&
               rect1.y + rect1.height > rect2.y;
    }
    
    createExplosion(x, y, color) {
        const particleCount = 8;
        
        for (let i = 0; i < particleCount; i++) {
            const angle = (i / particleCount) * Math.PI * 2;
            const speed = 3 + Math.random() * 2;
            
            const particle = {
                x: x,
                y: y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: 3 + Math.random() * 3,
                color: color,
                life: 1.0,
                decay: 0.02 + Math.random() * 0.01
            };
            
            this.particles.push(particle);
        }
    }
    
    spawnPowerUp() {
        const powerUpTypes = [
            { type: 'rapidfire', color: '#00ff00', size: 20 },
            { type: 'multishot', color: '#0080ff', size: 20 }
        ];
        
        const powerUpType = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];
        
        const powerUp = {
            x: Math.random() * (this.canvas.width - powerUpType.size),
            y: -powerUpType.size,
            width: powerUpType.size,
            height: powerUpType.size,
            speed: 1.5,
            type: powerUpType.type,
            color: powerUpType.color,
            rotation: 0
        };
        
        this.powerUps.push(powerUp);
        console.log('Power-up spawned:', powerUp.type);
    }
    
    updatePowerUps(currentTime) {
        // Decrease power-up effect timers
        if (this.rapidFire && currentTime > this.rapidFireTime) {
            this.rapidFire = false;
            console.log('Rapid fire ended');
        }
        
        if (this.multiShot && currentTime > this.multiShotTime) {
            this.multiShot = false;
            console.log('Multi-shot ended');
        }
    }
    
    updatePowerUpObjects() {
        for (let i = this.powerUps.length - 1; i >= 0; i--) {
            const powerUp = this.powerUps[i];
            powerUp.y += powerUp.speed;
            powerUp.rotation += 0.1; // Spinning effect
            
            // Remove power-ups that fall off screen
            if (powerUp.y > this.canvas.height) {
                this.powerUps.splice(i, 1);
            }
        }
    }
    
    updateParticles() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];
            
            // Update position
            particle.x += particle.vx;
            particle.y += particle.vy;
            
            // Apply gravity and friction
            particle.vy += 0.1;
            particle.vx *= 0.98;
            
            // Reduce life
            particle.life -= particle.decay;
            
            // Remove dead particles
            if (particle.life <= 0) {
                this.particles.splice(i, 1);
            }
        }
    }
    
    updateScore() {
        this.scoreElement.textContent = `Score: ${this.score}`;
    }
    
    updateLives() {
        this.livesElement.textContent = `Lives: ${this.lives}`;
    }
    
    updateWave() {
        this.waveElement.textContent = `Wave: ${this.wave}`;
    }
    
    loseLife() {
        this.lives--;
        this.updateLives();
        console.log('Lives remaining:', this.lives);
        
        if (this.lives <= 0) {
            this.gameOver();
        }
    }
    
    loadHighScore() {
        try {
            const highScore = localStorage.getItem('spaceShooterHighScore');
            return highScore ? parseInt(highScore) : 0;
        } catch (error) {
            console.log('Failed to load high score:', error);
            return 0;
        }
    }
    
    saveHighScore() {
        try {
            localStorage.setItem('spaceShooterHighScore', this.highScore.toString());
            console.log('High score saved:', this.highScore);
        } catch (error) {
            console.log('Failed to save high score:', error);
        }
    }
    
    gameOver() {
        console.log('Game Over! Final score:', this.score);
        this.gameState = 'gameOver';
        
        // Stop background music
        this.sounds.background.pause();
        
        // Check for new high score
        if (this.score > this.highScore) {
            this.highScore = this.score;
            this.saveHighScore();
            console.log('New high score!', this.highScore);
        }
        
        this.finalScoreElement.textContent = this.score;
        this.displayHighScoreElement.textContent = this.highScore;
        this.gameOverElement.classList.remove('hidden');
    }
    
    render() {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw background
        this.drawBackground();
        
        // Draw game objects
        this.drawPlayer();
        this.drawBullets();
        this.drawEnemies();
        this.drawPowerUps();
        this.drawParticles();
        
    }
    
    drawBackground() {
        // Create starfield background
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
        gradient.addColorStop(0, '#000428');
        gradient.addColorStop(1, '#004e92');
        
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw stars as part of background
        this.drawStars();
    }
    
    drawStars() {
        this.ctx.fillStyle = '#ffffff';
        
        // Draw random stars
        for (let i = 0; i < 50; i++) {
            const x = (i * 137.5) % this.canvas.width;
            const y = (i * 200.7) % this.canvas.height;
            const size = (i % 3) + 1;
            
            this.ctx.fillRect(x, y, size, size);
        }
    }
    
    drawPlayer() {
        // Draw spaceship as triangle
        this.ctx.fillStyle = this.player.color;
        this.ctx.beginPath();
        this.ctx.moveTo(this.player.x + this.player.width / 2, this.player.y);
        this.ctx.lineTo(this.player.x, this.player.y + this.player.height);
        this.ctx.lineTo(this.player.x + this.player.width, this.player.y + this.player.height);
        this.ctx.closePath();
        this.ctx.fill();
        
        // Add glow effect
        this.ctx.strokeStyle = '#00ff00';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
    }
    
    drawBullets() {
        this.bullets.forEach(bullet => {
            this.ctx.fillStyle = bullet.color;
            this.ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
            
            // Add glow effect
            this.ctx.shadowColor = bullet.color;
            this.ctx.shadowBlur = 5;
            this.ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
            this.ctx.shadowBlur = 0;
        });
    }
    
    drawEnemies() {
        this.enemies.forEach(enemy => {
            this.ctx.fillStyle = enemy.color;
            
            // Draw different shapes based on enemy type
            switch (enemy.type) {
                case 'basic':
                    // Square
                    this.ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
                    break;
                    
                case 'fast':
                    // Triangle
                    this.ctx.beginPath();
                    this.ctx.moveTo(enemy.x + enemy.width / 2, enemy.y);
                    this.ctx.lineTo(enemy.x, enemy.y + enemy.height);
                    this.ctx.lineTo(enemy.x + enemy.width, enemy.y + enemy.height);
                    this.ctx.closePath();
                    this.ctx.fill();
                    break;
                    
                case 'tank':
                    // Circle
                    this.ctx.beginPath();
                    this.ctx.arc(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, 
                               enemy.width / 2, 0, 2 * Math.PI);
                    this.ctx.fill();
                    break;
                    
                case 'zigzag':
                    // Diamond
                    this.ctx.beginPath();
                    this.ctx.moveTo(enemy.x + enemy.width / 2, enemy.y);
                    this.ctx.lineTo(enemy.x + enemy.width, enemy.y + enemy.height / 2);
                    this.ctx.lineTo(enemy.x + enemy.width / 2, enemy.y + enemy.height);
                    this.ctx.lineTo(enemy.x, enemy.y + enemy.height / 2);
                    this.ctx.closePath();
                    this.ctx.fill();
                    break;
                    
                default:
                    this.ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
                    break;
            }
            
            // Add border
            this.ctx.strokeStyle = '#ffffff';
            this.ctx.lineWidth = 2;
            this.ctx.stroke();
        });
    }
    
    drawPowerUps() {
        this.powerUps.forEach(powerUp => {
            this.ctx.save();
            
            // Move to center for rotation
            this.ctx.translate(powerUp.x + powerUp.width / 2, powerUp.y + powerUp.height / 2);
            this.ctx.rotate(powerUp.rotation);
            
            // Draw power-up based on type
            switch (powerUp.type) {
                case 'rapidfire':
                    // Draw rapid fire icon (lightning bolt-like)
                    this.ctx.fillStyle = powerUp.color;
                    this.ctx.beginPath();
                    this.ctx.moveTo(-8, -10);
                    this.ctx.lineTo(3, -2);
                    this.ctx.lineTo(-3, 0);
                    this.ctx.lineTo(8, 10);
                    this.ctx.lineTo(-3, 2);
                    this.ctx.lineTo(3, 0);
                    this.ctx.closePath();
                    this.ctx.fill();
                    break;
                    
                case 'multishot':
                    // Draw multi-shot icon (three arrows)
                    this.ctx.fillStyle = powerUp.color;
                    this.ctx.fillRect(-2, -10, 4, 8);
                    this.ctx.fillRect(-8, -6, 4, 8);
                    this.ctx.fillRect(4, -6, 4, 8);
                    // Arrow heads
                    this.ctx.beginPath();
                    this.ctx.moveTo(0, -10);
                    this.ctx.lineTo(-3, -7);
                    this.ctx.lineTo(3, -7);
                    this.ctx.closePath();
                    this.ctx.fill();
                    
                    this.ctx.beginPath();
                    this.ctx.moveTo(-6, -6);
                    this.ctx.lineTo(-9, -3);
                    this.ctx.lineTo(-3, -3);
                    this.ctx.closePath();
                    this.ctx.fill();
                    
                    this.ctx.beginPath();
                    this.ctx.moveTo(6, -6);
                    this.ctx.lineTo(3, -3);
                    this.ctx.lineTo(9, -3);
                    this.ctx.closePath();
                    this.ctx.fill();
                    break;
            }
            
            // Add glow effect
            this.ctx.shadowColor = powerUp.color;
            this.ctx.shadowBlur = 10;
            this.ctx.strokeStyle = powerUp.color;
            this.ctx.lineWidth = 2;
            this.ctx.stroke();
            
            this.ctx.restore();
        });
    }
    
    drawParticles() {
        this.particles.forEach(particle => {
            const alpha = particle.life;
            this.ctx.save();
            
            // Set alpha based on particle life
            this.ctx.globalAlpha = alpha;
            
            // Draw particle
            this.ctx.fillStyle = particle.color;
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.size, 0, 2 * Math.PI);
            this.ctx.fill();
            
            // Add glow effect
            this.ctx.shadowColor = particle.color;
            this.ctx.shadowBlur = particle.size * 2;
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.size, 0, 2 * Math.PI);
            this.ctx.fill();
            
            this.ctx.restore();
        });
    }
}

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing game...');
    const game = new SpaceShooterGame();
});

// Handle window resize
window.addEventListener('resize', () => {
    // Game canvas size is handled by CSS, but we might need to adjust game logic here
    console.log('Window resized');
});
