# Overview

This is a full-stack web application featuring a space shooter game built with React, Three.js, and Express.js. The project combines both a traditional 2D canvas-based space shooter game and modern 3D React Three Fiber components, with a complete backend infrastructure supporting PostgreSQL database integration via Drizzle ORM.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React 18** with TypeScript for component-based UI development
- **Vite** as the build tool and development server with hot module replacement
- **Three.js ecosystem** including React Three Fiber, Drei, and post-processing for 3D graphics
- **Tailwind CSS** with shadcn/ui component library for modern, responsive styling
- **Zustand** for lightweight state management (game state and audio controls)
- **TanStack Query** for server state management and API data fetching
- **Radix UI** primitives for accessible, unstyled components

## Game Implementation
The application features a dual approach to game development:
- **Canvas-based 2D Game**: Traditional space shooter implemented with HTML5 Canvas and vanilla JavaScript
- **3D Components**: React Three Fiber setup ready for 3D game elements with GLSL shader support
- **Audio System**: Integrated sound management with mute/unmute controls and multiple audio tracks
- **Game State Management**: Zustand-powered state management for game phases (ready, playing, ended)

## Backend Architecture  
- **Express.js** server with TypeScript for API endpoints
- **Memory Storage Pattern**: Abstracted storage interface allowing easy swapping between in-memory and database storage
- **Modular Route System**: Clean separation of route definitions from server setup
- **Development Tools**: Custom logging middleware and Vite integration for development workflow

## Database Layer
- **Drizzle ORM** with PostgreSQL dialect for type-safe database operations
- **Neon Database** integration via serverless connection pooling
- **Migration System**: Organized migration files in dedicated directory structure
- **Schema Validation**: Zod integration for runtime type checking and validation

## Build and Development
- **Unified Build Process**: Single command builds both client and server with proper bundling
- **Development Mode**: Integrated Vite dev server with Express backend proxy
- **Asset Handling**: Support for 3D models (GLTF/GLB), audio files, and GLSL shaders
- **TypeScript Configuration**: Shared types between client and server via workspace setup

## Styling and UI Framework
- **Design System**: Custom CSS variable-based theming with dark mode support
- **Component Library**: Extensive shadcn/ui integration with 30+ pre-built components
- **Responsive Design**: Mobile-first approach with Tailwind's utility-first methodology
- **Animation Support**: Built-in transitions and animations for smooth user interactions

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle Kit**: Database migration and schema management tools

## Frontend Libraries
- **@tanstack/react-query**: Server state management and caching
- **@react-three/fiber**: React renderer for Three.js
- **@react-three/drei**: Useful helpers and abstractions for React Three Fiber
- **@react-three/postprocessing**: Post-processing effects for 3D scenes
- **Radix UI**: Accessible component primitives (@radix-ui/*)
- **Tailwind CSS**: Utility-first CSS framework with PostCSS processing

## Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Static type checking across the entire stack
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Runtime error overlay and development environment support

## Utility Libraries
- **Zustand**: Lightweight state management with subscriptions
- **Zod**: Runtime type validation and schema parsing
- **clsx**: Conditional className utility
- **date-fns**: Date manipulation and formatting